
<?php $__env->startSection('title', 'MY LARAVEL SYSTEM'); ?>

<?php $__env->startSection('content'); ?>
<section class="section" align="center">
    <div class="section-header">
        <h3 class="page_heading">Permisos</h3>
    </div>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-permisos')): ?>
                        <a href="<?php echo e(route('permisos.create')); ?>" class="btn btn-warning"> Nuevo</a>
                        <?php endif; ?>
                        <table class="table">

                            <head>
                                <tr align="left">
                                    <th>Permiso</th>
                                    <th>Acciones</th>
                                </tr>
                            </head>
                            <tbody>
                                <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($permiso->name); ?></td>    
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-permiso')): ?>
                                            <a href="<?php echo e(route('permisos.edit',$permiso->id)); ?>" class="btn btn-primary"> Editar</a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-permiso')): ?>
                                        <?php echo Form::open(['method'=>'DELETE','class' => 'd-inline form-delete', 'style'=>'display:inline', 'route'=>['permisos.destroy',$permiso->id]]); ?>

                                            <?php echo Form::submit('Borrar',['class'=>'btn btn-danger']); ?>

                                        <?php echo Form::close(); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center"> <?php echo $permisos->links(); ?> </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php if(Session::has('permiso_deleted')): ?>
<script>
    Swal.fire(
        'Borrado!',
        'El permiso ha sido eliminado.',
        'Exito'
    )
</script>
<?php endif; ?>
<?php if(Session::has('permiso_edited')): ?>
<script>
    Swal.fire(
        'Editado!',
        'El permiso ha sido editado.',
        'Exito'
    )
</script>
<?php endif; ?>
<?php if(Session::has('permiso_added')): ?>
<script>
    Swal.fire(
        'Agregado!',
        'El permiso ha sido agregado.',
        'Exito'
    )
</script>
<?php endif; ?>
<script>
    $('.form-delete').submit(function(e) {
        e.preventDefault();
        Swal.fire({
            title: 'Está seguro?',
            text: "No se podrá revertir!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, Eliminarlo!'
        }).then((result) => {
            if (result.isConfirmed) {
                this.submit();
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ct-jet-home\resources\views/permisos/index.blade.php ENDPATH**/ ?>