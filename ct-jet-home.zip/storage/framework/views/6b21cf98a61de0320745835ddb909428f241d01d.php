
<?php $__env->startSection('title', 'MY LARAVEL SYSTEM'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-5" align="left">
    <?php if($errors->any()): ?>
    <div class="alert alert-dark alert-dismissible fade show" role="alert">
        <strong>¡Revise los campos!</strong>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="badge badge-danger"><?php echo e($error); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <?php if(isset($client)): ?>
    <h1>Editar</h1>
    <?php else: ?>
    <h1>Crear</h1>
    <?php endif; ?>
    <?php if(isset($client)): ?>
    <form action="<?php echo e(route('client.update',$client)); ?>" method="post" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php else: ?>
        <form action="<?php echo e(route('client.store')); ?>" method="post" enctype="multipart/form-data">
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Nombre</label>
                <input type="text" name="name" class="form-control" placeholder="Nombre del cliente" value="<?php echo e(old('name') ?? @$client->name); ?>">
            </div>
            <div class="mb-3">
                <label for="due" class="form-label">Saldo</label>
                <input type="text" name="due" class="form-control" placeholder="Saldo del cliente" step="0.01" value="<?php echo e(old('due') ?? @$client->due); ?>">
            </div>
            <?php if(isset($client)): ?>
            <div class="input-group mb-3">
                <img height="50px" src="<?php echo e(asset('images/'.$client->image)); ?>" />
            </div>
            <?php endif; ?>
            <div class="input-group mb-3">
                <label for="ImageControl" />Seleccione imagen</label>
                <input type="file" class="form-control-file" name=" image" id="inputGroupFile03" aria-describedby="inputGroupFileAddon03" aria-label="Upload">
            </div>
            <div class="mb-3">
                <label for="comments" class="form-label">Comentarios</label>
                <textarea name="comments" id="comments" cols="30" rows="10" class="form-control" placeholder="Escriba un comentario"><?php echo e(old('comments') ?? @$client->comments); ?></textarea>
            </div>
            <?php if(isset($client)): ?>
            <button type="submit" class="btn btn-info">Guardar cambios</button>
            <?php else: ?>
            <button type="submit" class="btn btn-info">Guardar clientes</button>
            <?php endif; ?>

        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ct-jet-home\resources\views/client/form.blade.php ENDPATH**/ ?>