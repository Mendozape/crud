
<?php $__env->startSection('title', 'MY LARAVEL SYSTEM'); ?>

<?php $__env->startSection('content'); ?>
<section class="section" align="center">
  <div class="section-header">
    <h3 class="page_heading">Usuarios</h3>
  </div>
  <div class="section-body">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-usuario')): ?>
            <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-warning"> New</a>
            <?php endif; ?>
            <table class="table">

              <head>
                <tr align="left">
                  <th style="display:none;">ID</th>
                  <th>Nombre</th>
                  <th>E-mail</th>
                  <th>Role</th>
                  <th>Permisos</th>
                  <th>Acciones</th>
                </tr>
              </head>
              <tbody>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td style="display:none;"><?php echo e($details->id); ?></td>
                  <td><?php echo e($details->name); ?></td>
                  <td><?php echo e($details->email); ?></td>
                  <td>
                    <?php if(!empty($details->getRoleNames())): ?>
                    <?php $__currentLoopData = $details->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5><span class="btn btn-primary btn-sm"><?php echo e($roleName); ?></span></h5>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  <td>
                    <?php $__currentLoopData = $details->getAllPermissions()->pluck('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permisos2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="btn btn-primary btn-sm"><?php echo e($permisos2); ?></span> </br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-usuario')): ?>
                    <a href="<?php echo e(route('usuarios.edit',$details->id)); ?>" class="btn btn-info">Editar</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-usuario')): ?>
                    <form action="<?php echo e(route('usuarios.destroy',$details->id)); ?>" method="post" class="d-inline form-delete">
                      <?php echo method_field('DELETE'); ?>
                      <?php echo csrf_field(); ?>
                      <BUTTON type="submit" class="btn btn-danger">Eliminar</BUTTON>
                      <?php endif; ?>
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <div class="d-flex justify-content-center"> <?php echo $usuarios->links(); ?> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php if(Session::has('user_deleted')): ?>
<script>
  Swal.fire(
    'Borrado!',
    'El usuario ha sido eliminado.',
    'Exito'
  )
</script>
<?php endif; ?>
<?php if(Session::has('user_edited')): ?>
<script>
  Swal.fire(
    'Editado!',
    'El usuario ha sido editado.',
    'Exito'
  )
</script>
<?php endif; ?>
<?php if(Session::has('user_added')): ?>
<script>
  Swal.fire(
    'Agregado!',
    'El usuario ha sido agregado.',
    'Exito'
  )
</script>
<?php endif; ?>
<script>
  $('.form-delete').submit(function(e) {
    e.preventDefault();
    Swal.fire({
      title: 'Está seguro?',
      text: "No se podrá revertir!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí, Eliminarlo!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.submit();
      }
    })
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ct-jet-home\resources\views/usuarios/index.blade.php ENDPATH**/ ?>