
<?php $__env->startSection('title', 'MY LARAVEL SYSTEM'); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-header" align="center">
    <h1>Listado</h1>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-cliente')): ?>
    <a href="<?php echo e(route('client.create')); ?>" class="btn btn-primary"> Altas</a>
    <?php endif; ?>
  </div>
  <div class="section-body">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <table class="table">
              <tr>
                <th>Nombre</th>
                <th>Saldo</th>
                <th>Comentarios</th>
                <th>Imagen</th>
                <th>Acciones</th>
              </tr>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td><?php echo e($details->name); ?></td>
                  <td><?php echo e($details->due); ?></td>
                  <td><?php echo e($details->comments); ?></td>
                  <!--<td><img height="50px" src="<?php echo e(asset('storage/images/products/'.$details->image)); ?>" /></td>-->
                  <td><img height="50px" src="<?php echo e(asset('images/'.$details->image)); ?>" /></td>
                  <td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-cliente')): ?>
                    <a href="<?php echo e(route('client.edit',$details)); ?>" class="btn btn-warning">Editar</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-cliente')): ?>
                    <form action="<?php echo e(route('client.destroy',$details)); ?>" method="post" class="d-inline form-delete">
                      <?php echo method_field('DELETE'); ?>
                      <?php echo csrf_field(); ?>
                      <BUTTON type="submit" class="btn btn-danger">Eliminar</BUTTON>
                    </form>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="3">No hay registros</td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
            <div class="pagination justify-content-center"> <?php echo $clientes->links(); ?> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php if(Session::has('user_deleted')): ?>
<script>
  Swal.fire(
    'Borrado!',
    'El registro ha sido eliminado.',
    'Exito'
  )
</script>
<?php endif; ?>
<?php if(Session::has('user_edited')): ?>
<script>
  Swal.fire(
    'Editado!',
    'El registro ha sido editado.',
    'Exito'
  )
</script>
<?php endif; ?>
<?php if(Session::has('user_added')): ?>
<script>
  Swal.fire(
    'Agregado!',
    'El registro ha sido agregado.',
    'Exito'
  )
</script>
<?php endif; ?>
<script>
  $('.form-delete').submit(function(e) {
    e.preventDefault();
    Swal.fire({
      title: 'Está seguro?',
      text: "No se podrá revertir!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí, Eliminarlo!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.submit();
      }
    })
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ct-jet-home\resources\views/client/index.blade.php ENDPATH**/ ?>