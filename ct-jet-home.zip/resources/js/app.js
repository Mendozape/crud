import './bootstrap';
window.Swal = require('sweetalert2');

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
